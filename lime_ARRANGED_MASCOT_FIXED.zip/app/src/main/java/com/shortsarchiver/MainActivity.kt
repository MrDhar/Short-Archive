package com.shortsarchiver

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.content.res.ColorStateList
import android.graphics.Color
import android.widget.CheckBox
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.card.MaterialCardView
import com.shortsarchiver.databinding.ActivityMainBinding
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.Executors

class MainActivity : AppCompatActivity() {
    private lateinit var b: ActivityMainBinding
    private val executor = Executors.newSingleThreadExecutor()
    private val discovered = mutableListOf<Video>()
    private val selected = linkedSetOf<String>()

    private val archiveFile by lazy {
        File(getExternalFilesDir(Environment.DIRECTORY_MOVIES), "ShortsArchive/download-archive.txt")
    }

    private val outputDir by lazy {
        File(getExternalFilesDir(Environment.DIRECTORY_MOVIES), "ShortsArchive").apply { mkdirs() }
    }

    data class Video(val id: String, val title: String, val url: String)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        b = ActivityMainBinding.inflate(layoutInflater)
        setContentView(b.root)
        archiveFile.parentFile?.mkdirs()

        b.status.text = "Ready"
        b.activity.text = "Connect YouTube, then enter a public channel URL."

        b.connectButton.setOnClickListener { openYouTube("/youtube/connect") }
        b.accountButton.setOnClickListener { openYouTube("/youtube/account") }
        b.refreshAccountButton.setOnClickListener { refreshAccount() }
        b.discoverButton.setOnClickListener { discover() }
        b.selectAllButton.setOnClickListener { selectAll() }
        b.downloadButton.setOnClickListener { downloadSelected() }
        b.uploadButton.setOnClickListener { queueSelectedForUpload() }
        b.refreshQueueButton.setOnClickListener { refreshQueue() }

        refreshAccount()
        refreshQueue()
    }

    override fun onResume() {
        super.onResume()
        refreshAccount()
        refreshQueue()
    }

    private fun backendUrl(): String? {
        val raw = b.backendUrl.text?.toString()?.trim().orEmpty()
            .trimEnd('/')
            .ifBlank { "https://shorts-archive-backend.onrender.com" }
        if (!raw.startsWith("http://") && !raw.startsWith("https://")) return null
        return raw
    }

    private fun channelUrl(): String? {
        val raw = b.channelUrl.text?.toString()?.trim().orEmpty()
        if (!raw.startsWith("http://") && !raw.startsWith("https://")) return null
        return raw
    }

    private fun openYouTube(path: String) {
        val base = backendUrl() ?: run {
            b.status.text = "Enter a valid backend URL"
            return
        }
        startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("$base$path")))
    }

    private fun get(base: String, path: String): Pair<Int, String> {
        val conn = (URL("$base$path").openConnection() as HttpURLConnection).apply {
            requestMethod = "GET"
            connectTimeout = 20_000
            readTimeout = 30_000
            setRequestProperty("Accept", "*/*")
        }
        return try {
            val code = conn.responseCode
            val stream = if (code in 200..299) conn.inputStream else conn.errorStream
            code to (stream?.bufferedReader()?.use { it.readText() }.orEmpty())
        } finally {
            conn.disconnect()
        }
    }

    private fun postJson(base: String, path: String, body: JSONObject): HttpURLConnection {
        val conn = (URL("$base$path").openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"
            connectTimeout = 20_000
            readTimeout = 15 * 60_000
            doOutput = true
            setRequestProperty("Content-Type", "application/json")
            setRequestProperty("Accept", "application/json")
        }
        conn.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
        return conn
    }

    private fun refreshAccount() {
        val base = backendUrl() ?: return
        executor.execute {
            try {
                val (code, text) = get(base, "/youtube/account")
                val lower = text.lowercase()
                val connected = code in 200..299 &&
                    ("connected" in lower || "disconnect" in lower) &&
                    !("connect your youtube account" in lower && "connect youtube account" in lower)

                runOnUiThread {
                    b.accountStatus.text = if (connected) "✓ YouTube connected" else "YouTube not connected"
                    b.accountStatus.setTextColor(
                        getColor(if (connected) android.R.color.holo_green_dark else android.R.color.darker_gray)
                    )
                    b.uploadButton.isEnabled = connected && selected.isNotEmpty()
                }
            } catch (_: Exception) {
                runOnUiThread {
                    b.accountStatus.text = "YouTube connection status unavailable"
                    b.uploadButton.isEnabled = false
                }
            }
        }
    }


    private fun refreshQueue() {
        val base = backendUrl() ?: return
        executor.execute {
            try {
                val (code, text) = get(base, "/upload-queue")
                if (code !in 200..299) throw IllegalStateException(
                    text.ifBlank { "Queue endpoint returned HTTP $code" }
                )

                val status = JSONObject(text).optJSONObject("status")
                    ?: throw IllegalStateException("Invalid queue response")

                val waiting = status.optInt("queued", 0)
                val processing = status.optInt("processing", 0)
                val uploadedToday = status.optInt("uploaded_last_24h", 0)
                val limit = status.optInt("daily_limit", 8)
                val nextId = status.optString("next_video_id", "")

                runOnUiThread {
                    b.queueWaitingCount.text = waiting.toString()
                    b.queueProcessingCount.text = processing.toString()
                    b.queueUploadedCount.text = "$uploadedToday / $limit"
                    b.queueSummaryTitle.text = when {
                        uploadedToday >= limit -> "Daily limit reached"
                        processing > 0 -> "Upload in progress"
                        waiting > 0 -> "$waiting Shorts waiting"
                        else -> "Queue is clear"
                    }
                    b.queueSummarySubtitle.text =
                        "$waiting waiting  •  $uploadedToday / $limit uploaded today"
                    b.queueNextText.text = if (nextId.isNotBlank()) {
                        "Next in line  •  $nextId"
                    } else {
                        "Nothing waiting"
                    }
                }
            } catch (e: Exception) {
                runOnUiThread {
                    b.queueSummaryTitle.text = "Queue unavailable"
                    b.queueSummarySubtitle.text = "Could not sync with the server"
                    b.queueNextText.text = e.message ?: "Tap Refresh to try again"
                }
            }
        }
    }

    private fun discover() {
        val base = backendUrl() ?: run {
            b.status.text = "Backend URL required"
            return
        }
        val channel = channelUrl() ?: run {
            b.status.text = "Paste a full public YouTube channel URL."
            return
        }

        setBusy(true)
        b.status.text = "Discovering public Shorts…"
        b.activity.text = "Scanning in batches of 500…"
        b.progress.progress = 0

        executor.execute {
            try {
                val all = mutableListOf<Video>()
                val seen = linkedSetOf<String>()
                val batchSize = 500
                var offset = 0

                while (true) {
                    val body = JSONObject()
                        .put("channel_url", channel)
                        .put("offset", offset)
                        .put("limit", batchSize)

                    val conn = postJson(base, "/discover", body)
                    val code = conn.responseCode
                    val stream = if (code in 200..299) conn.inputStream else conn.errorStream
                    val text = stream?.bufferedReader()?.use { it.readText() }.orEmpty()
                    conn.disconnect()

                    if (code !in 200..299) {
                        throw IllegalStateException(text.ifBlank { "Backend returned HTTP $code" })
                    }

                    val json = JSONObject(text)
                    val entries = json.optJSONArray("entries") ?: break
                    var addedThisBatch = 0

                    for (i in 0 until entries.length()) {
                        val obj = entries.getJSONObject(i)
                        val id = obj.optString("id")
                        if (!id.matches(Regex("[A-Za-z0-9_-]{11}")) || !seen.add(id)) continue

                        all.add(
                            Video(
                                id = id,
                                title = obj.optString("title").ifBlank { "YouTube Short $id" },
                                url = obj.optString("url").ifBlank {
                                    "https://www.youtube.com/shorts/$id"
                                }
                            )
                        )
                        addedThisBatch++
                    }

                    runOnUiThread {
                        b.foundCount.text = all.size.toString()
                        b.progress.progress = if (entries.length() < batchSize) 100
                        else (all.size % 10000) / 100
                        b.activity.text = "Found ${all.size} Shorts…"
                    }

                    // A short/empty batch means there is nothing more to fetch.
                    if (entries.length() < batchSize || addedThisBatch == 0) break
                    offset += entries.length()

                    // Backend safety ceiling.
                    if (offset >= 50000) break
                }

                synchronized(discovered) {
                    discovered.clear()
                    discovered.addAll(all)
                    selected.clear()
                }

                runOnUiThread {
                    renderVideos()
                    updateCounts()
                    b.status.text = "Discovery complete — ${all.size} Shorts found."
                    b.activity.text = if (all.isEmpty()) {
                        "No Shorts were found."
                    } else {
                        "Select the Shorts you want, then choose Download or Add to Upload Queue."
                    }
                    setBusy(false)
                }
            } catch (e: Exception) {
                runOnUiThread {
                    b.status.text = "Discovery failed"
                    b.activity.text = e.message ?: "Unknown error"
                    setBusy(false)
                }
            }
        }
    }

    private fun renderVideos() {
        b.videoList.removeAllViews()
        val snapshot = synchronized(discovered) { discovered.toList() }

        for ((index, video) in snapshot.withIndex()) {
            val card = MaterialCardView(this).apply {
                layoutParams = LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT
                ).apply {
                    topMargin = if (index == 0) 0 else 7.dp()
                }
                radius = 12.dp().toFloat()
                cardElevation = 0f
                strokeWidth = 1.dp()
                strokeColor = Color.rgb(17, 20, 13)
                setCardBackgroundColor(Color.rgb(232, 255, 147))
            }

            val row = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(10.dp(), 9.dp(), 10.dp(), 9.dp())
            }

            val check = CheckBox(this).apply {
                text = video.title
                isChecked = selected.contains(video.id)
                textSize = 14f
                setTextColor(Color.rgb(17, 20, 13))
                buttonTintList = ColorStateList(
                    arrayOf(
                        intArrayOf(android.R.attr.state_checked),
                        intArrayOf()
                    ),
                    intArrayOf(Color.rgb(17, 20, 13), Color.rgb(113, 128, 59))
                )
                setPadding(0, 0, 0, 0)
                setOnCheckedChangeListener { _, checked ->
                    if (checked) selected.add(video.id) else selected.remove(video.id)
                    updateCounts()
                }
            }

            val idText = TextView(this).apply {
                text = "ID ${video.id}   •   youtube.com/shorts/${video.id}"
                textSize = 9f
                setTextColor(Color.rgb(70, 80, 44))
                setPadding(44.dp(), 0, 0, 0)
                typeface = android.graphics.Typeface.create("monospace", android.graphics.Typeface.NORMAL)
            }

            row.addView(check)
            row.addView(idText)
            card.addView(row)
            b.videoList.addView(card)
        }
        b.selectAllButton.isEnabled = snapshot.isNotEmpty()
        updateCounts()
    }

    private fun Int.dp(): Int = (this * resources.displayMetrics.density).toInt()

    private fun selectAll() {
        synchronized(discovered) {
            selected.clear()
            selected.addAll(discovered.map { it.id })
        }
        renderVideos()
    }

    private fun downloadSelected() {
        val ids = synchronized(discovered) {
            discovered.filter { selected.contains(it.id) }.map { it.id }
        }
        if (ids.isEmpty()) {
            b.status.text = "Select at least one Short."
            return
        }

        val base = backendUrl() ?: run {
            b.status.text = "Backend URL required"
            return
        }

        setBusy(true)
        b.status.text = "Starting downloads…"

        executor.execute {
            val archived = readArchive().toMutableSet()
            val queue = ids.filter { it !in archived }
            var done = 0
            var failed = 0

            for ((index, id) in queue.withIndex()) {
                try {
                    val conn = postJson(base, "/download", JSONObject().put("video_id", id))
                    val code = conn.responseCode
                    if (code !in 200..299) {
                        val error = conn.errorStream?.bufferedReader()?.use { it.readText() }.orEmpty()
                        conn.disconnect()
                        throw IllegalStateException(error.ifBlank { "HTTP $code" })
                    }

                    val suggested = conn.getHeaderField("Content-Disposition")
                        ?.substringAfter("filename=", "")
                        ?.trim('"', '\'')
                        ?.takeIf { it.isNotBlank() }
                    val safeName = (suggested ?: "$id.mp4").replace(Regex("[^A-Za-z0-9._-]"), "_")
                    val target = File(outputDir, safeName)

                    conn.inputStream.use { input ->
                        target.outputStream().use { output ->
                            val buffer = ByteArray(64 * 1024)
                            while (true) {
                                val n = input.read(buffer)
                                if (n <= 0) break
                                output.write(buffer, 0, n)
                            }
                        }
                    }
                    conn.disconnect()

                    appendArchive(id)
                    archived.add(id)
                    done++
                    val overall = ((index + 1) * 100f / queue.size.coerceAtLeast(1)).toInt()
                    runOnUiThread {
                        b.progress.progress = overall
                        b.status.text = "Downloading ${index + 1}/${queue.size}"
                        b.activity.text = safeName
                    }
                } catch (e: Exception) {
                    failed++
                    runOnUiThread { b.activity.text = "Failed $id: ${e.message ?: "unknown error"}" }
                }
            }

            runOnUiThread {
                updateCounts()
                b.progress.progress = 100
                b.status.text = "Download complete — $done succeeded, $failed failed."
                b.activity.text = "Downloaded files are stored in ShortsArchive."
                setBusy(false)
            }
        }
    }

    private fun queueSelectedForUpload() {
        val ids = synchronized(discovered) {
            discovered.filter { selected.contains(it.id) }.map { it.id }
        }
        if (ids.isEmpty()) {
            b.status.text = "Select at least one Short."
            return
        }

        val base = backendUrl() ?: run {
            b.status.text = "Backend URL required"
            return
        }

        setBusy(true)
        b.status.text = "Adding ${ids.size} Shorts to upload queue…"
        b.activity.text = "Videos are NOT being downloaded to your phone."

        executor.execute {
            try {
                var added = 0
                var skipped = 0
                val chunkSize = 500

                for (startIndex in ids.indices step chunkSize) {
                    val endIndex = minOf(startIndex + chunkSize, ids.size)
                    val chunk = ids.subList(startIndex, endIndex)
                    val arr = org.json.JSONArray()
                    chunk.forEach { arr.put(it) }

                    val body = JSONObject().put("video_ids", arr)
                    val conn = postJson(base, "/upload-queue/add", body)
                    val code = conn.responseCode
                    val stream = if (code in 200..299) conn.inputStream else conn.errorStream
                    val text = stream?.bufferedReader()?.use { it.readText() }.orEmpty()
                    conn.disconnect()

                    if (code !in 200..299) {
                        throw IllegalStateException(text.ifBlank { "Queue endpoint returned HTTP $code" })
                    }

                    val json = JSONObject(text)
                    added += json.optInt("added", 0)
                    skipped += json.optInt("skipped", 0)

                    val done = endIndex
                    runOnUiThread {
                        b.progress.progress = (done * 100 / ids.size.coerceAtLeast(1))
                        b.activity.text = "Queued $done/${ids.size} selected Shorts…"
                    }
                }

                // Fetch server-side status so the UI confirms persistence.
                val (statusCode, statusText) = get(base, "/upload-queue")
                var queueTotal = -1
                if (statusCode in 200..299) {
                    queueTotal = JSONObject(statusText).optJSONObject("status")
                        ?.optInt("queue_total", -1) ?: -1
                }

                runOnUiThread {
                    b.progress.progress = 100
                    b.status.text = "Upload queue ready — $added added."
                    b.activity.text = if (queueTotal >= 0) {
                        "Server queue: $queueTotal total • $skipped already queued/uploaded."
                    } else {
                        "$skipped were already queued/uploaded."
                    }
                    refreshQueue()
                    setBusy(false)
                }
            } catch (e: Exception) {
                runOnUiThread {
                    b.status.text = "Could not create upload queue"
                    b.activity.text = e.message ?: "Unknown error"
                    setBusy(false)
                }
            }
        }
    }

    private fun uploadMultipart(base: String, file: File, realTitle: String) {
        val boundary = "----ShortsArchiver${System.currentTimeMillis()}"
        val conn = (URL("$base/youtube/upload").openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"
            connectTimeout = 20_000
            readTimeout = 15 * 60_000
            doOutput = true
            setRequestProperty("Content-Type", "multipart/form-data; boundary=$boundary")
            setRequestProperty("Accept", "application/json")
        }

        val out = conn.outputStream
        fun field(name: String, value: String) {
            out.write("--$boundary\r\n".toByteArray())
            out.write("Content-Disposition: form-data; name=\"$name\"\r\n\r\n".toByteArray())
            out.write(value.toByteArray(Charsets.UTF_8))
            out.write("\r\n".toByteArray())
        }

        field("title", realTitle)
        field("description", "Uploaded with Shorts Archiver")
        field("privacy_status", "public")

        out.write("--$boundary\r\n".toByteArray())
        out.write("Content-Disposition: form-data; name=\"video\"; filename=\"${file.name}\"\r\n".toByteArray())
        out.write("Content-Type: video/mp4\r\n\r\n".toByteArray())
        file.inputStream().use { input -> input.copyTo(out, 64 * 1024) }
        out.write("\r\n--$boundary--\r\n".toByteArray())
        out.close()

        val code = conn.responseCode
        val stream = if (code in 200..299) conn.inputStream else conn.errorStream
        val body = stream?.bufferedReader()?.use { it.readText() }.orEmpty()
        conn.disconnect()
        if (code !in 200..299) {
            throw IllegalStateException(body.ifBlank { "YouTube upload endpoint returned HTTP $code" })
        }
    }

    private fun appendArchive(id: String) {
        archiveFile.parentFile?.mkdirs()
        archiveFile.appendText("$id\n")
    }

    private fun readArchive(): Set<String> {
        if (!archiveFile.exists()) return emptySet()
        return archiveFile.readLines().map { it.trim() }
            .filter { it.matches(Regex("[A-Za-z0-9_-]{11}")) }.toSet()
    }

    private fun updateCounts() {
        val archived = readArchive()
        val snapshot = synchronized(discovered) { discovered.toList() }
        val a = snapshot.count { it.id in archived }
        val s = selected.size
        runOnUiThread {
            b.foundCount.text = snapshot.size.toString()
            b.archivedCount.text = a.toString()
            b.todoCount.text = (snapshot.size - a).toString()
            b.selectedCount.text = "$s selected"
            b.downloadButton.isEnabled = s > 0
            b.uploadButton.isEnabled = s > 0
        }
    }

    private fun setBusy(busy: Boolean) {
        runOnUiThread {
            b.connectButton.isEnabled = !busy
            b.accountButton.isEnabled = !busy
            b.refreshAccountButton.isEnabled = !busy
            b.discoverButton.isEnabled = !busy
            b.selectAllButton.isEnabled = !busy && discovered.isNotEmpty()
            b.downloadButton.isEnabled = !busy && selected.isNotEmpty()
            b.uploadButton.isEnabled = !busy && selected.isNotEmpty()
        }
    }

    override fun onDestroy() {
        executor.shutdownNow()
        super.onDestroy()
    }
}
