# Shorts Archiver Android V3 — YouTube Connected Frontend

This version replaces the old downloader-only screen with a YouTube-connected UI.

## Frontend changes

- YouTube Account card
- Connect YouTube button
- Account page button
- Connection status refresh
- Public Shorts discovery
- Select individual Shorts
- Select All
- Download selected Shorts
- Upload selected downloaded Shorts to YouTube
- Progress/status feedback

## OAuth callback

The Android app opens the backend's existing:

`/youtube/connect`

The backend must continue to use exactly:

`/oauth/callback`

Do not change this to `/oauth2callback`.

## Backend endpoints expected

Existing:
- `GET /youtube/connect`
- `GET /youtube/account`
- `POST /discover`
- `POST /download`

For the new Upload button, the backend needs:
- `POST /youtube/upload`
- multipart field `video`
- optional fields `title`, `description`, `privacy_status`

If `/youtube/upload` is not present in the current backend, the new UI will still build and the connection/discovery/download features will work, but upload will return an endpoint error until that backend route is added.

## Build

Open the project in Android Studio and run `assembleDebug`.

The original repository did not contain a Gradle wrapper, so this archive is source-ready rather than a prebuilt APK.


## V4 UI refresh

The app now uses a dark lime/black retro control-deck visual system with monospace typography, compact bordered cards, lime primary actions, simplified queue metrics, and card-based discovered Shorts. Existing backend endpoints and archive/upload behavior are preserved.
