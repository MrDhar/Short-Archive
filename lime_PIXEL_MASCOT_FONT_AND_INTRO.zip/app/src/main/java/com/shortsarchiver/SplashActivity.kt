package com.shortsarchiver

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.widget.VideoView
import androidx.appcompat.app.AppCompatActivity

class SplashActivity : AppCompatActivity() {
    private val handler = Handler(Looper.getMainLooper())
    private var opened = false

    private fun openMain() {
        if (opened || isFinishing) return
        opened = true
        startActivity(Intent(this, MainActivity::class.java))
        finish()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_splash)

        val video = findViewById<VideoView>(R.id.introVideo)
        video.setVideoURI(Uri.parse("android.resource://$packageName/${R.raw.lime_intro}"))
        video.setOnCompletionListener { openMain() }
        video.setOnErrorListener { _, _, _ ->
            openMain()
            true
        }
        video.start()

        // Never keep the user on the intro for too long.
        handler.postDelayed({ openMain() }, 3000L)
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        super.onDestroy()
    }
}
