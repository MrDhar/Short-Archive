package com.shortsarchiver

import android.os.Bundle
import android.os.Environment
import androidx.appcompat.app.AppCompatActivity
import com.shortsarchiver.databinding.ActivityMainBinding
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.Executors

class MainActivity : AppCompatActivity() {
    private lateinit var b: ActivityMainBinding
    private val executor = Executors.newSingleThreadExecutor()
    private val discovered = mutableListOf<String>()

    private val archiveFile by lazy {
        File(getExternalFilesDir(Environment.DIRECTORY_MOVIES), "ShortsArchive/download-archive.txt")
    }

    private val outputDir by lazy {
        File(getExternalFilesDir(Environment.DIRECTORY_MOVIES), "ShortsArchive").apply { mkdirs() }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        b = ActivityMainBinding.inflate(layoutInflater)
        setContentView(b.root)
        archiveFile.parentFile?.mkdirs()

        b.status.text = "Ready"
        b.activity.text = "Enter your backend URL, then paste a public YouTube channel URL."

        b.discoverButton.setOnClickListener { discover() }
        b.downloadButton.setOnClickListener { downloadAll() }
    }

    private fun backendUrl(): String? {
        val raw = b.backendUrl.text?.toString()?.trim().orEmpty().trimEnd('/').ifBlank { "https://shorts-archive-backend.onrender.com" }
        if (!raw.startsWith("http://") && !raw.startsWith("https://")) return null
        return raw
    }

    private fun channelUrl(): String? {
        val raw = b.channelUrl.text?.toString()?.trim().orEmpty()
        if (!raw.startsWith("http://") && !raw.startsWith("https://")) return null
        return raw
    }

    private fun postJson(base: String, path: String, body: JSONObject): HttpURLConnection {
        val conn = (URL("$base$path").openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"
            connectTimeout = 20_000
            readTimeout = 15 * 60_000
            doOutput = true
            setRequestProperty("Content-Type", "application/json")
            setRequestProperty("Accept", "application/json")
        }
        conn.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
        return conn
    }

    private fun discover() {
        val base = backendUrl() ?: run {
            b.status.text = "Backend URL required"
            return
        }
        val channel = channelUrl() ?: run {
            b.status.text = "Paste a full public YouTube channel URL."
            return
        }

        setBusy(true)
        b.status.text = "Discovering public Shorts…"
        b.activity.text = "Contacting backend…"
        b.progress.progress = 0

        executor.execute {
            try {
                val conn = postJson(base, "/discover", JSONObject().put("channel_url", channel))
                val code = conn.responseCode
                val stream = if (code in 200..299) conn.inputStream else conn.errorStream
                val text = stream?.bufferedReader()?.use { it.readText() }.orEmpty()
                conn.disconnect()

                if (code !in 200..299) throw IllegalStateException(text.ifBlank { "Backend returned HTTP $code" })

                val json = JSONObject(text)
                val entries = json.optJSONArray("entries") ?: throw IllegalStateException("No entries returned")
                val ids = linkedSetOf<String>()
                for (i in 0 until entries.length()) {
                    val id = entries.getJSONObject(i).optString("id")
                    if (id.matches(Regex("[A-Za-z0-9_-]{11}"))) ids.add(id)
                }

                synchronized(discovered) {
                    discovered.clear()
                    discovered.addAll(ids)
                }
                updateCounts()

                runOnUiThread {
                    b.status.text = "Discovery complete — ${discovered.size} Shorts found."
                    b.activity.text = if (discovered.isEmpty()) "No Shorts were found." else "Ready to download."
                    b.downloadButton.isEnabled = discovered.isNotEmpty()
                    setBusy(false)
                }
            } catch (e: Exception) {
                runOnUiThread {
                    b.status.text = "Discovery failed"
                    b.activity.text = e.message ?: "Unknown error"
                    setBusy(false)
                }
            }
        }
    }

    private fun downloadAll() {
        if (discovered.isEmpty()) return
        val base = backendUrl() ?: run {
            b.status.text = "Backend URL required"
            return
        }

        setBusy(true)
        b.status.text = "Starting downloads…"

        executor.execute {
            val archived = readArchive().toMutableSet()
            val queue = synchronized(discovered) { discovered.filter { it !in archived } }
            var done = 0
            var failed = 0

            for ((index, id) in queue.withIndex()) {
                try {
                    val conn = postJson(base, "/download", JSONObject().put("video_id", id))
                    val code = conn.responseCode
                    if (code !in 200..299) {
                        val error = conn.errorStream?.bufferedReader()?.use { it.readText() }.orEmpty()
                        conn.disconnect()
                        throw IllegalStateException(error.ifBlank { "HTTP $code" })
                    }

                    val suggested = conn.getHeaderField("Content-Disposition")
                        ?.substringAfter("filename=", "")
                        ?.trim('"', '\'')
                        ?.takeIf { it.isNotBlank() }
                    val targetName = suggested ?: "${id}.mp4"
                    val safeName = targetName.replace(Regex("[^A-Za-z0-9._-]"), "_")
                    val target = File(outputDir, safeName)
                    conn.inputStream.use { input -> target.outputStream().use { output ->
                        val buffer = ByteArray(64 * 1024)
                        var total = 0L
                        while (true) {
                            val n = input.read(buffer)
                            if (n <= 0) break
                            output.write(buffer, 0, n)
                            total += n
                        }
                    }}
                    conn.disconnect()

                    appendArchive(id)
                    archived.add(id)
                    done++
                    val overall = ((index + 1) * 100f / queue.size.coerceAtLeast(1)).toInt()
                    runOnUiThread {
                        b.progress.progress = overall
                        b.status.text = "Downloading ${index + 1}/${queue.size}"
                        b.activity.text = safeName
                    }
                } catch (e: Exception) {
                    failed++
                    runOnUiThread { b.activity.text = "Failed $id: ${e.message ?: "unknown error"}" }
                }
            }

            runOnUiThread {
                updateCounts()
                b.progress.progress = 100
                b.status.text = "Download complete — $done succeeded, $failed failed."
                b.activity.text = "Files are in the app's ShortsArchive folder."
                setBusy(false)
            }
        }
    }

    private fun appendArchive(id: String) {
        archiveFile.parentFile?.mkdirs()
        archiveFile.appendText("$id\n")
    }

    private fun readArchive(): Set<String> {
        if (!archiveFile.exists()) return emptySet()
        return archiveFile.readLines().map { it.trim() }
            .filter { it.matches(Regex("[A-Za-z0-9_-]{11}")) }.toSet()
    }

    private fun updateCounts() {
        val archived = readArchive()
        val snapshot = synchronized(discovered) { discovered.toList() }
        val a = snapshot.count { it in archived }
        runOnUiThread {
            b.foundCount.text = snapshot.size.toString()
            b.archivedCount.text = a.toString()
            b.todoCount.text = (snapshot.size - a).toString()
        }
    }

    private fun setBusy(busy: Boolean) {
        runOnUiThread {
            b.discoverButton.isEnabled = !busy
            b.downloadButton.isEnabled = !busy && discovered.isNotEmpty()
        }
    }

    override fun onDestroy() {
        executor.shutdownNow()
        super.onDestroy()
    }
}
