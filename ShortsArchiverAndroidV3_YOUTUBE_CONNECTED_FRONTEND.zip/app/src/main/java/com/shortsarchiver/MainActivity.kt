package com.shortsarchiver

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.view.View
import android.widget.CheckBox
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.shortsarchiver.databinding.ActivityMainBinding
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.util.concurrent.Executors

class MainActivity : AppCompatActivity() {
    private lateinit var b: ActivityMainBinding
    private val executor = Executors.newSingleThreadExecutor()
    private val discovered = mutableListOf<Video>()
    private val selected = linkedSetOf<String>()

    private val archiveFile by lazy {
        File(getExternalFilesDir(Environment.DIRECTORY_MOVIES), "ShortsArchive/download-archive.txt")
    }

    private val outputDir by lazy {
        File(getExternalFilesDir(Environment.DIRECTORY_MOVIES), "ShortsArchive").apply { mkdirs() }
    }

    data class Video(val id: String, val title: String, val url: String)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        b = ActivityMainBinding.inflate(layoutInflater)
        setContentView(b.root)
        archiveFile.parentFile?.mkdirs()

        b.status.text = "Ready"
        b.activity.text = "Connect YouTube, then enter a public channel URL."

        b.connectButton.setOnClickListener { openYouTube("/youtube/connect") }
        b.accountButton.setOnClickListener { openYouTube("/youtube/account") }
        b.refreshAccountButton.setOnClickListener { refreshAccount() }
        b.discoverButton.setOnClickListener { discover() }
        b.selectAllButton.setOnClickListener { selectAll() }
        b.downloadButton.setOnClickListener { downloadSelected() }
        b.uploadButton.setOnClickListener { uploadSelected() }

        refreshAccount()
    }

    override fun onResume() {
        super.onResume()
        refreshAccount()
    }

    private fun backendUrl(): String? {
        val raw = b.backendUrl.text?.toString()?.trim().orEmpty()
            .trimEnd('/')
            .ifBlank { "https://shorts-archive-backend.onrender.com" }
        if (!raw.startsWith("http://") && !raw.startsWith("https://")) return null
        return raw
    }

    private fun channelUrl(): String? {
        val raw = b.channelUrl.text?.toString()?.trim().orEmpty()
        if (!raw.startsWith("http://") && !raw.startsWith("https://")) return null
        return raw
    }

    private fun openYouTube(path: String) {
        val base = backendUrl() ?: run {
            b.status.text = "Enter a valid backend URL"
            return
        }
        startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("$base$path")))
    }

    private fun get(base: String, path: String): Pair<Int, String> {
        val conn = (URL("$base$path").openConnection() as HttpURLConnection).apply {
            requestMethod = "GET"
            connectTimeout = 20_000
            readTimeout = 30_000
            setRequestProperty("Accept", "*/*")
        }
        return try {
            val code = conn.responseCode
            val stream = if (code in 200..299) conn.inputStream else conn.errorStream
            code to (stream?.bufferedReader()?.use { it.readText() }.orEmpty())
        } finally {
            conn.disconnect()
        }
    }

    private fun postJson(base: String, path: String, body: JSONObject): HttpURLConnection {
        val conn = (URL("$base$path").openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"
            connectTimeout = 20_000
            readTimeout = 15 * 60_000
            doOutput = true
            setRequestProperty("Content-Type", "application/json")
            setRequestProperty("Accept", "application/json")
        }
        conn.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
        return conn
    }

    private fun refreshAccount() {
        val base = backendUrl() ?: return
        executor.execute {
            try {
                val (code, text) = get(base, "/youtube/account")
                val lower = text.lowercase()
                val connected = code in 200..299 &&
                    ("connected" in lower || "disconnect" in lower) &&
                    !("connect your youtube account" in lower && "connect youtube account" in lower)

                runOnUiThread {
                    b.accountStatus.text = if (connected) "✓ YouTube connected" else "YouTube not connected"
                    b.accountStatus.setTextColor(
                        getColor(if (connected) android.R.color.holo_green_dark else android.R.color.darker_gray)
                    )
                    b.uploadButton.isEnabled = connected && selected.isNotEmpty()
                }
            } catch (_: Exception) {
                runOnUiThread {
                    b.accountStatus.text = "YouTube connection status unavailable"
                    b.uploadButton.isEnabled = false
                }
            }
        }
    }

    private fun discover() {
        val base = backendUrl() ?: run {
            b.status.text = "Backend URL required"
            return
        }
        val channel = channelUrl() ?: run {
            b.status.text = "Paste a full public YouTube channel URL."
            return
        }

        setBusy(true)
        b.status.text = "Discovering public Shorts…"
        b.activity.text = "Contacting backend…"
        b.progress.progress = 0

        executor.execute {
            try {
                val conn = postJson(base, "/discover", JSONObject().put("channel_url", channel))
                val code = conn.responseCode
                val stream = if (code in 200..299) conn.inputStream else conn.errorStream
                val text = stream?.bufferedReader()?.use { it.readText() }.orEmpty()
                conn.disconnect()
                if (code !in 200..299) throw IllegalStateException(text.ifBlank { "Backend returned HTTP $code" })

                val json = JSONObject(text)
                val entries = json.optJSONArray("entries") ?: throw IllegalStateException("No entries returned")
                val fresh = mutableListOf<Video>()
                val seen = linkedSetOf<String>()

                for (i in 0 until entries.length()) {
                    val obj = entries.getJSONObject(i)
                    val id = obj.optString("id")
                    if (!id.matches(Regex("[A-Za-z0-9_-]{11}")) || !seen.add(id)) continue
                    fresh.add(
                        Video(
                            id = id,
                            title = obj.optString("title").ifBlank { "YouTube Short $id" },
                            url = obj.optString("url").ifBlank { "https://www.youtube.com/shorts/$id" }
                        )
                    )
                    if (fresh.size >= 500) break
                }

                synchronized(discovered) {
                    discovered.clear()
                    discovered.addAll(fresh)
                    selected.clear()
                    selected.addAll(fresh.map { it.id })
                }

                runOnUiThread {
                    renderVideos()
                    updateCounts()
                    b.status.text = "Discovery complete — ${fresh.size} Shorts found."
                    b.activity.text = if (fresh.isEmpty()) "No Shorts were found." else "Select Shorts to download or upload."
                    setBusy(false)
                }
            } catch (e: Exception) {
                runOnUiThread {
                    b.status.text = "Discovery failed"
                    b.activity.text = e.message ?: "Unknown error"
                    setBusy(false)
                }
            }
        }
    }

    private fun renderVideos() {
        b.videoList.removeAllViews()
        val snapshot = synchronized(discovered) { discovered.toList() }

        for (video in snapshot) {
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(4, 12, 4, 12)
            }

            val check = CheckBox(this).apply {
                text = video.title
                isChecked = selected.contains(video.id)
                textSize = 16f
                setOnCheckedChangeListener { _, checked ->
                    if (checked) selected.add(video.id) else selected.remove(video.id)
                    updateCounts()
                }
            }

            val idText = TextView(this).apply {
                text = "youtube.com/shorts/${video.id}"
                textSize = 12f
                alpha = 0.65f
            }

            row.addView(check)
            row.addView(idText)
            b.videoList.addView(row)
        }
        b.selectAllButton.isEnabled = snapshot.isNotEmpty()
        updateCounts()
    }

    private fun selectAll() {
        synchronized(discovered) {
            selected.clear()
            selected.addAll(discovered.map { it.id })
        }
        renderVideos()
    }

    private fun downloadSelected() {
        val ids = synchronized(discovered) {
            discovered.filter { selected.contains(it.id) }.map { it.id }
        }
        if (ids.isEmpty()) {
            b.status.text = "Select at least one Short."
            return
        }

        val base = backendUrl() ?: run {
            b.status.text = "Backend URL required"
            return
        }

        setBusy(true)
        b.status.text = "Starting downloads…"

        executor.execute {
            val archived = readArchive().toMutableSet()
            val queue = ids.filter { it !in archived }
            var done = 0
            var failed = 0

            for ((index, id) in queue.withIndex()) {
                try {
                    val conn = postJson(base, "/download", JSONObject().put("video_id", id))
                    val code = conn.responseCode
                    if (code !in 200..299) {
                        val error = conn.errorStream?.bufferedReader()?.use { it.readText() }.orEmpty()
                        conn.disconnect()
                        throw IllegalStateException(error.ifBlank { "HTTP $code" })
                    }

                    val suggested = conn.getHeaderField("Content-Disposition")
                        ?.substringAfter("filename=", "")
                        ?.trim('"', '\'')
                        ?.takeIf { it.isNotBlank() }
                    val safeName = (suggested ?: "$id.mp4").replace(Regex("[^A-Za-z0-9._-]"), "_")
                    val target = File(outputDir, safeName)

                    conn.inputStream.use { input ->
                        target.outputStream().use { output ->
                            val buffer = ByteArray(64 * 1024)
                            while (true) {
                                val n = input.read(buffer)
                                if (n <= 0) break
                                output.write(buffer, 0, n)
                            }
                        }
                    }
                    conn.disconnect()

                    appendArchive(id)
                    archived.add(id)
                    done++
                    val overall = ((index + 1) * 100f / queue.size.coerceAtLeast(1)).toInt()
                    runOnUiThread {
                        b.progress.progress = overall
                        b.status.text = "Downloading ${index + 1}/${queue.size}"
                        b.activity.text = safeName
                    }
                } catch (e: Exception) {
                    failed++
                    runOnUiThread { b.activity.text = "Failed $id: ${e.message ?: "unknown error"}" }
                }
            }

            runOnUiThread {
                updateCounts()
                b.progress.progress = 100
                b.status.text = "Download complete — $done succeeded, $failed failed."
                b.activity.text = "Downloaded files are stored in ShortsArchive."
                setBusy(false)
            }
        }
    }

    private fun uploadSelected() {
        val ids = synchronized(discovered) {
            discovered.filter { selected.contains(it.id) }.map { it.id }
        }
        if (ids.isEmpty()) {
            b.status.text = "Select at least one Short."
            return
        }

        val files = ids.mapNotNull { id ->
            outputDir.listFiles()?.firstOrNull { it.name.startsWith(id) && it.isFile && it.length() > 0 }
        }

        if (files.isEmpty()) {
            b.status.text = "Download the selected Shorts first."
            return
        }

        val base = backendUrl() ?: run {
            b.status.text = "Backend URL required"
            return
        }

        setBusy(true)
        b.status.text = "Uploading to YouTube…"

        executor.execute {
            var done = 0
            var failed = 0
            for ((index, file) in files.withIndex()) {
                try {
                    uploadMultipart(base, file)
                    done++
                    runOnUiThread {
                        b.progress.progress = ((index + 1) * 100f / files.size).toInt()
                        b.activity.text = "Uploaded ${file.name}"
                    }
                } catch (e: Exception) {
                    failed++
                    runOnUiThread { b.activity.text = "Upload failed ${file.name}: ${e.message ?: "unknown error"}" }
                }
            }
            runOnUiThread {
                b.status.text = "Upload complete — $done succeeded, $failed failed."
                setBusy(false)
                refreshAccount()
            }
        }
    }

    private fun uploadMultipart(base: String, file: File) {
        val boundary = "----ShortsArchiver${System.currentTimeMillis()}"
        val conn = (URL("$base/youtube/upload").openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"
            connectTimeout = 20_000
            readTimeout = 15 * 60_000
            doOutput = true
            setRequestProperty("Content-Type", "multipart/form-data; boundary=$boundary")
            setRequestProperty("Accept", "application/json")
        }

        val title = file.nameWithoutExtension
        val out = conn.outputStream
        fun field(name: String, value: String) {
            out.write("--$boundary\r\n".toByteArray())
            out.write("Content-Disposition: form-data; name=\"$name\"\r\n\r\n".toByteArray())
            out.write(value.toByteArray(Charsets.UTF_8))
            out.write("\r\n".toByteArray())
        }

        field("title", title)
        field("description", "Uploaded with Shorts Archiver")
        field("privacy_status", "private")

        out.write("--$boundary\r\n".toByteArray())
        out.write("Content-Disposition: form-data; name=\"video\"; filename=\"${file.name}\"\r\n".toByteArray())
        out.write("Content-Type: video/mp4\r\n\r\n".toByteArray())
        file.inputStream().use { input -> input.copyTo(out, 64 * 1024) }
        out.write("\r\n--$boundary--\r\n".toByteArray())
        out.close()

        val code = conn.responseCode
        val stream = if (code in 200..299) conn.inputStream else conn.errorStream
        val body = stream?.bufferedReader()?.use { it.readText() }.orEmpty()
        conn.disconnect()
        if (code !in 200..299) {
            throw IllegalStateException(body.ifBlank { "YouTube upload endpoint returned HTTP $code" })
        }
    }

    private fun appendArchive(id: String) {
        archiveFile.parentFile?.mkdirs()
        archiveFile.appendText("$id\n")
    }

    private fun readArchive(): Set<String> {
        if (!archiveFile.exists()) return emptySet()
        return archiveFile.readLines().map { it.trim() }
            .filter { it.matches(Regex("[A-Za-z0-9_-]{11}")) }.toSet()
    }

    private fun updateCounts() {
        val archived = readArchive()
        val snapshot = synchronized(discovered) { discovered.toList() }
        val a = snapshot.count { it.id in archived }
        val s = selected.size
        runOnUiThread {
            b.foundCount.text = snapshot.size.toString()
            b.archivedCount.text = a.toString()
            b.todoCount.text = (snapshot.size - a).toString()
            b.selectedCount.text = "$s selected"
            b.downloadButton.isEnabled = s > 0
            b.uploadButton.isEnabled = s > 0
        }
    }

    private fun setBusy(busy: Boolean) {
        runOnUiThread {
            b.connectButton.isEnabled = !busy
            b.accountButton.isEnabled = !busy
            b.refreshAccountButton.isEnabled = !busy
            b.discoverButton.isEnabled = !busy
            b.selectAllButton.isEnabled = !busy && discovered.isNotEmpty()
            b.downloadButton.isEnabled = !busy && selected.isNotEmpty()
            b.uploadButton.isEnabled = !busy && selected.isNotEmpty()
        }
    }

    override fun onDestroy() {
        executor.shutdownNow()
        super.onDestroy()
    }
}
