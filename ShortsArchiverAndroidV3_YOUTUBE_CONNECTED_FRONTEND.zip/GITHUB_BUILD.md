# Shorts Archiver — GitHub-only APK build

This package is specifically prepared for phone-only use.

## No Gradle wrapper required

GitHub Actions installs Gradle 8.13 on its Ubuntu runner, so you do **not** need:
- Android Studio
- Python
- Gradle
- a Gradle wrapper on your phone

## Upload

In your GitHub repository, use **Add file → Upload files** and upload the contents of this folder:

```text
.github/
app/
build.gradle.kts
settings.gradle.kts
gradle.properties
README.md
GITHUB_BUILD.md
```

Do not upload the ZIP itself.

## Build

1. Open GitHub → your `Short-Archive` repository.
2. Tap **Actions**.
3. Select **Build Android APK**.
4. Tap **Run workflow**.
5. Wait for the green check.
6. Open that completed workflow run.
7. Scroll to **Artifacts**.
8. Download `ShortsArchiver-debug-apk`.
9. Extract it and install `app-debug.apk` on your Android phone.

The workflow builds `:app:assembleDebug`.
