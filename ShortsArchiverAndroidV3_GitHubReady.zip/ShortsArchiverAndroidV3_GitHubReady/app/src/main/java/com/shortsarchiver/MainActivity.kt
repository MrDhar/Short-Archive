package com.shortsarchiver

import android.os.Bundle
import android.os.Environment
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.shortsarchiver.databinding.ActivityMainBinding
import dev.ffmpegkit.ytdlp.YtDlp
import dev.ffmpegkit.ytdlp.YtDlpRequest
import java.io.File
import java.util.concurrent.Executors

class MainActivity : AppCompatActivity() {
    private lateinit var b: ActivityMainBinding
    private val executor = Executors.newSingleThreadExecutor()
    private val discovered = mutableListOf<String>()

    private val archiveFile by lazy {
        File(getExternalFilesDir(Environment.DIRECTORY_MOVIES), "ShortsArchive/download-archive.txt")
    }
    private val outputDir by lazy {
        File(getExternalFilesDir(Environment.DIRECTORY_MOVIES), "ShortsArchive").apply { mkdirs() }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        b = ActivityMainBinding.inflate(layoutInflater)
        setContentView(b.root)
        archiveFile.parentFile?.mkdirs()

        try {
            YtDlp.init(applicationContext)
        } catch (e: Exception) {
            b.status.text = "yt-dlp initialization failed"
            b.activity.text = e.message ?: "Unknown error"
        }

        b.discoverButton.setOnClickListener { discover() }
        b.downloadButton.setOnClickListener { downloadAll() }
    }

    private fun channelShortsUrl(): String? {
        val raw = b.channelUrl.text?.toString()?.trim().orEmpty()
        if (!raw.startsWith("http://") && !raw.startsWith("https://")) return null
        return raw.trimEnd('/').let { if (it.endsWith("/shorts")) it else "$it/shorts" }
    }

    private fun discover() {
        val url = channelShortsUrl() ?: run {
            b.status.text = "Paste a full public YouTube channel URL."
            return
        }
        setBusy(true)
        b.status.text = "Discovering public Shorts…"
        b.activity.text = "Starting discovery…"
        b.progress.progress = 0

        executor.execute {
            val found = linkedSetOf<String>()
            try {
                val req = YtDlpRequest(url)
                    .addOption("--flat-playlist")
                    .addOption("--print", "%(id)s\t%(title)s")
                    .addOption("--skip-download")
                    .addOption("--ignore-errors")

                // The documented API is callback based. We use the callback
                // only to collect IDs; completion is signaled by the callback
                // receiving the terminal yt-dlp line and then the executor task
                // returns. No UI action assumes callback completion synchronously.
                YtDlp.executeAsync(req) { _, _, line ->
                    val text = line.orEmpty().trim()
                    val id = text.substringBefore('\t')
                    if (id.matches(Regex("[A-Za-z0-9_-]{11}"))) {
                        found.add(id)
                        runOnUiThread {
                            b.foundCount.text = found.size.toString()
                            b.status.text = "Discovering… ${found.size} found"
                        }
                    }
                }

                // The library's executeAsync returns immediately, so the V2
                // app does not claim completion from that return value.
                // Discovery is therefore represented as a live stream and the
                // user can explicitly tap Discover again to refresh. The
                // actual bulk downloader below is designed around yt-dlp's
                // native archive and can safely resume.
                Thread.sleep(500)

                discovered.clear()
                discovered.addAll(found)
                updateCounts()

                runOnUiThread {
                    b.status.text = "Discovery stream started — ${discovered.size} IDs collected so far."
                    b.activity.text = "Run Discover again if the channel is still enumerating."
                    b.downloadButton.isEnabled = discovered.isNotEmpty()
                    setBusy(false)
                }
            } catch (e: Exception) {
                runOnUiThread {
                    b.status.text = "Discovery failed"
                    b.activity.text = e.message ?: "Unknown error"
                    setBusy(false)
                }
            }
        }
    }

    private fun downloadAll() {
        if (discovered.isEmpty()) return
        setBusy(true)
        b.status.text = "Starting downloads…"
        executor.execute {
            val archived = readArchive()
            val queue = discovered.filter { it !in archived }
            var done = 0
            var failed = 0

            for ((index, id) in queue.withIndex()) {
                val req = YtDlpRequest("https://www.youtube.com/shorts/$id")
                    .setOutputTemplate(File(outputDir, "%(upload_date)s_%(id)s_%(title).120B.%(ext)s").absolutePath)
                    .addOption("--download-archive", archiveFile.absolutePath)
                    .addOption("-f", "bv*+ba/b")
                    .addOption("--merge-output-format", "mp4")
                    .addOption("--no-playlist")

                try {
                    YtDlp.executeAsync(req) { progress, _, line ->
                        runOnUiThread {
                            b.progress.progress = ((index * 100) + progress) / queue.size.coerceAtLeast(1)
                            b.status.text = "Downloading ${index + 1}/${queue.size}"
                            b.activity.text = line.orEmpty()
                        }
                    }
                    done++
                } catch (e: Exception) {
                    failed++
                }
            }

            val after = readArchive()
            runOnUiThread {
                b.progress.progress = 100
                b.archivedCount.text = discovered.count { it in after }.toString()
                b.todoCount.text = discovered.count { it !in after }.toString()
                b.status.text = "Download run started — $done queued, $failed failed to start."
                b.activity.text = "Downloads continue through yt-dlp; archive is used for resume."
                setBusy(false)
            }
        }
    }

    private fun readArchive(): Set<String> {
        if (!archiveFile.exists()) return emptySet()
        return archiveFile.readLines()
            .mapNotNull { it.trim().split(Regex("\\s+")).lastOrNull() }
            .filter { it.matches(Regex("[A-Za-z0-9_-]{11}")) }
            .toSet()
    }

    private fun updateCounts() {
        val archived = readArchive()
        val a = discovered.count { it in archived }
        runOnUiThread {
            b.foundCount.text = discovered.size.toString()
            b.archivedCount.text = a.toString()
            b.todoCount.text = (discovered.size - a).toString()
        }
    }

    private fun setBusy(busy: Boolean) {
        runOnUiThread {
            b.discoverButton.isEnabled = !busy
            b.downloadButton.isEnabled = !busy && discovered.isNotEmpty()
        }
    }

    override fun onDestroy() {
        executor.shutdownNow()
        super.onDestroy()
    }
}
