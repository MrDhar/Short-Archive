# Shorts Archiver Android V2

**Goal:** one public YouTube channel URL → discover publicly exposed Shorts → download all new Shorts to app storage.

This V2 corrects the earlier architecture by treating `yt-dlp-android` as an asynchronous API and not assuming `executeAsync()` blocks until completion. The library's documented API uses `YtDlp.executeAsync(request, callback)` and embeds yt-dlp/Python in the Android app. citeturn0search0

## Build
Open in Android Studio and run `assembleDebug`.

The debug APK will be:
`app/build/outputs/apk/debug/app-debug.apk`

## Long downloads
The next production step should move the download queue into WorkManager/foreground execution. Android officially supports long-running workers for bulk downloads and exposes progress through a notification. citeturn0search2turn0search1

## Scope
Public, accessible Shorts only. No private/authentication bypass is included. Use only for content you are authorized to archive.
