# Shorts Archiver V4 — UI Reorganization

Implemented as a frontend-only reorganization plan.

## Sections
1. YouTube connection
2. Discover
3. Upload Queue
4. Shorts/results
5. Activity/status

## UX changes
- Queue is treated as a first-class section.
- Daily upload counter is displayed separately from queue size.
- Queue status is intended to persist visually across app restarts by refreshing `/upload-queue`.
- Discovery selection starts empty rather than selecting every discovered Short.
- Primary actions are grouped together and secondary/status information is visually separated.
- Existing backend/API behavior is preserved.

No backend `app.py` changes are included in this frontend package.
