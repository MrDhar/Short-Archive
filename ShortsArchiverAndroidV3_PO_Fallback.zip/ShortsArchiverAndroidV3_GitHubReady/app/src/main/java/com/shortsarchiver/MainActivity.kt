package com.shortsarchiver

import android.os.Bundle
import android.os.Environment
import androidx.appcompat.app.AppCompatActivity
import com.shortsarchiver.databinding.ActivityMainBinding
import dev.ffmpegkit_maintained.ytdlp.YtDlp
import dev.ffmpegkit_maintained.ytdlp.YtDlpRequest
import java.io.File
import java.util.concurrent.Executors

class MainActivity : AppCompatActivity() {
    private lateinit var b: ActivityMainBinding
    private val executor = Executors.newSingleThreadExecutor()
    private val discovered = mutableListOf<String>()

    private val archiveFile by lazy {
        File(
            getExternalFilesDir(Environment.DIRECTORY_MOVIES),
            "ShortsArchive/download-archive.txt"
        )
    }

    private val outputDir by lazy {
        File(
            getExternalFilesDir(Environment.DIRECTORY_MOVIES),
            "ShortsArchive"
        ).apply { mkdirs() }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        b = ActivityMainBinding.inflate(layoutInflater)
        setContentView(b.root)
        archiveFile.parentFile?.mkdirs()

        try {
            YtDlp.init(applicationContext)
            b.status.text = "Ready"
            b.activity.text = "Paste a public YouTube channel URL."
        } catch (e: Exception) {
            b.status.text = "yt-dlp initialization failed"
            b.activity.text = e.message ?: "Unknown error"
        }

        b.discoverButton.setOnClickListener { discover() }
        b.downloadButton.setOnClickListener { downloadAll() }
    }

    private fun channelShortsUrl(): String? {
        val raw = b.channelUrl.text?.toString()?.trim().orEmpty()
        if (!raw.startsWith("http://") && !raw.startsWith("https://")) return null

        return raw.trimEnd('/').let {
            if (it.endsWith("/shorts")) it else "$it/shorts"
        }
    }

    private fun discover() {
        val url = channelShortsUrl() ?: run {
            b.status.text = "Paste a full public YouTube channel URL."
            return
        }

        setBusy(true)
        b.status.text = "Discovering public Shorts…"
        b.activity.text = "Starting yt-dlp…"
        b.progress.progress = 0

        executor.execute {
            val found = linkedSetOf<String>()

            try {
                val req = YtDlpRequest(url)
                    .addOption("--flat-playlist")
                    .addOption("--lazy-playlist")
                    .addOption("--print", "%(id)s\t%(title)s")
                    .addOption("--skip-download")
                    .addOption("--ignore-errors")
                    // YouTube is currently enforcing PO tokens on several clients.
                    // These clients are used for discovery because they can expose
                    // playlist entries without requiring the normal GVS download path.
                    .addOption("--extractor-args", "youtube:player_client=android_vr,tv,web_embedded")

                val future = YtDlp.executeAsync(req) { _, _, line ->
                    val text = line.orEmpty().trim()
                    val id = text.substringBefore('\t')

                    if (id.matches(Regex("[A-Za-z0-9_-]{11}"))) {
                        synchronized(found) {
                            found.add(id)
                        }

                        runOnUiThread {
                            b.foundCount.text = found.size.toString()
                            b.status.text = "Discovering… ${found.size} found"
                        }
                    }
                }

                // Wait until yt-dlp has completely enumerated the channel.
                future.get()

                synchronized(found) {
                    discovered.clear()
                    discovered.addAll(found)
                }

                updateCounts()

                runOnUiThread {
                    b.status.text = "Discovery complete — ${discovered.size} Shorts found."
                    b.activity.text = if (discovered.isEmpty()) {
                        "No Shorts were found."
                    } else {
                        "Ready to download."
                    }
                    b.downloadButton.isEnabled = discovered.isNotEmpty()
                    setBusy(false)
                }
            } catch (e: Exception) {
                runOnUiThread {
                    b.status.text = "Discovery failed"
                    b.activity.text = e.message ?: "Unknown error"
                    setBusy(false)
                }
            }
        }
    }

    private fun downloadAll() {
        if (discovered.isEmpty()) return

        setBusy(true)
        b.status.text = "Starting downloads…"

        executor.execute {
            val archived = readArchive()
            val queue = discovered.filter { it !in archived }

            var done = 0
            var failed = 0

            for ((index, id) in queue.withIndex()) {
                val outputTemplate = File(
                    outputDir,
                    "%(upload_date)s_%(id)s_%(title).120B.%(ext)s"
                ).absolutePath

                try {
                    // First try the Android VR client with format 18. Current yt-dlp
                    // guidance indicates this client can still expose a directly
                    // downloadable H.264/AAC format without a GVS PO token.
                    val primary = YtDlpRequest("https://www.youtube.com/shorts/$id")
                        .setOutputTemplate(outputTemplate)
                        .addOption("--download-archive", archiveFile.absolutePath)
                        .addOption("--extractor-args", "youtube:player_client=android_vr")
                        .addOption("-f", "18/b")
                        .addOption("--no-playlist")

                    val future = YtDlp.executeAsync(primary) { progress: Float, _: Long, line: String ->
                        runOnUiThread {
                            val overall = ((index * 100f) + progress) /
                                queue.size.coerceAtLeast(1)
                            b.progress.progress = overall.toInt().coerceIn(0, 100)
                            b.status.text = "Downloading ${index + 1}/${queue.size}"
                            b.activity.text = line
                        }
                    }
                    future.get()
                    done++
                } catch (first: Exception) {
                    // Fallback for videos where format 18 is unavailable.
                    try {
                        val fallback = YtDlpRequest("https://www.youtube.com/shorts/$id")
                            .setOutputTemplate(outputTemplate)
                            .addOption("--download-archive", archiveFile.absolutePath)
                            .addOption("--extractor-args", "youtube:player_client=tv")
                            .addOption("-f", "bv*+ba/b")
                            .addOption("--merge-output-format", "mp4")
                            .addOption("--no-playlist")

                        val future = YtDlp.executeAsync(fallback) { progress: Float, _: Long, line: String ->
                            runOnUiThread {
                                val overall = ((index * 100f) + progress) /
                                    queue.size.coerceAtLeast(1)
                                b.progress.progress = overall.toInt().coerceIn(0, 100)
                                b.status.text = "Retrying ${index + 1}/${queue.size}"
                                b.activity.text = line
                            }
                        }
                        future.get()
                        done++
                    } catch (_: Exception) {
                        failed++
                    }
                }
            }

            val after = readArchive()

            runOnUiThread {
                b.progress.progress = 100
                b.archivedCount.text =
                    discovered.count { it in after }.toString()
                b.todoCount.text =
                    discovered.count { it !in after }.toString()

                b.status.text =
                    "Download complete — $done succeeded, $failed failed."
                b.activity.text =
                    "Downloaded files are in the app's ShortsArchive folder."
                setBusy(false)
            }
        }
    }

    private fun readArchive(): Set<String> {
        if (!archiveFile.exists()) return emptySet()

        return archiveFile.readLines()
            .mapNotNull { it.trim().split(Regex("\\s+")).lastOrNull() }
            .filter { it.matches(Regex("[A-Za-z0-9_-]{11}")) }
            .toSet()
    }

    private fun updateCounts() {
        val archived = readArchive()
        val a = discovered.count { it in archived }

        runOnUiThread {
            b.foundCount.text = discovered.size.toString()
            b.archivedCount.text = a.toString()
            b.todoCount.text = (discovered.size - a).toString()
        }
    }

    private fun setBusy(busy: Boolean) {
        runOnUiThread {
            b.discoverButton.isEnabled = !busy
            b.downloadButton.isEnabled = !busy && discovered.isNotEmpty()
        }
    }

    override fun onDestroy() {
        executor.shutdownNow()
        super.onDestroy()
    }
}
